Project Title : 
Lwanimations

Student Information : 
ST Number = ST10480624 
ST Name/Surname : 
Tumisang Moipolai

Project Overview (complete) :
Part 1 Complete, part to start 10 seotember, part tbd.

Website Goals and Objectives : 
Initial Success will be measured by being able to Drive traffic to the website and a potential sale. Long term Goals will be decided based on early performance.

Key Features and Functionality :
Easy Navigation
Animations
Animated Gallery

Timeline and Milestones : 
Part 1 Due: 27 August
Part 2 Due: 26 September
Part 3 Due: 19 November
Extra Due 10 December

Part 1 Details (Part 2 and Part 3 will follow in future submissions/edits) : 


Sitemap : 


Changelog: Begin tracking changes and improvements to the website. (Details have been
shared be low.) : 




References (You must cite all sourcesusing the recognised referencing style for the institution.) : 

